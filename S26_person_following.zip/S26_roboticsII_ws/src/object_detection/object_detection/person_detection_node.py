"""
person_detection_node.py
========================
Uses YOLOv8-pose to find the ankle midpoint of the nearest person
(same logic as leg_tracker.py), looks up the 3D position from the
depth point cloud, and publishes it as a PoseStamped so tracking_node
can drive the robot toward the person.

Subscribed:  /camera/color/image_raw   (Image)
             /camera/depth/points      (PointCloud2)
Published:   /detected_color_goal_pose (PoseStamped, in base_footprint)
             /detected_person          (Image, debug viz)
"""

import rclpy
from rclpy.node import Node
from message_filters import ApproximateTimeSynchronizer, Subscriber
from sensor_msgs.msg import Image, PointCloud2
from geometry_msgs.msg import PoseStamped
from tf2_ros import TransformException, Buffer, TransformListener
from cv_bridge import CvBridge
import cv2, struct, numpy as np
from ultralytics import YOLO

def hat(k):
    khat=np.zeros((3,3))
    khat[0,1]=-k[2]; khat[0,2]=k[1]
    khat[1,0]=k[2];  khat[1,2]=-k[0]
    khat[2,0]=-k[1]; khat[2,1]=k[0]
    return khat

def q2R(q):
    I=np.identity(3); qhat=hat(q[1:4]); qhat2=qhat.dot(qhat)
    return I + 2*q[0]*qhat + 2*qhat2


class PersonDetectionNode(Node):
    def __init__(self):
        super().__init__('person_detection_node')

        self.declare_parameter('conf_threshold', 0.4)
        self.conf = self.get_parameter('conf_threshold').value

        self.model = YOLO('yolov8n-pose.pt')
        self.br    = CvBridge()

        self.tf_buffer   = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        # Publish to the same topic tracking_node already listens to
        self.pub_pose  = self.create_publisher(PoseStamped, '/detected_color_goal_pose', 10)
        self.pub_image = self.create_publisher(Image, '/detected_person', 10)

        # Sync RGB + PointCloud2 — same pattern as color_obj_detection.py
        self.sub_rgb   = Subscriber(self, Image,       '/camera/color/image_raw')
        self.sub_depth = Subscriber(self, PointCloud2, '/camera/depth/points')
        self.ts = ApproximateTimeSynchronizer([self.sub_rgb, self.sub_depth], 10, 0.1)
        self.ts.registerCallback(self.callback)

        self.get_logger().info('Person Detection Node ready.')

    def get_ankle_midpoint(self, keypoints):
        """
        Your leg_tracker.py logic — find the ankle midpoint.
        Falls back to single ankle, then knees if one side is occluded.
        """
        la, ra = keypoints[15], keypoints[16]   # left/right ankle
        lk, rk = keypoints[13], keypoints[14]   # left/right knee

        la_ok = la[2] > self.conf
        ra_ok = ra[2] > self.conf

        if la_ok and ra_ok:
            return int((la[0]+ra[0])/2), int((la[1]+ra[1])/2)
        elif la_ok:
            return int(la[0]), int(la[1])
        elif ra_ok:
            return int(ra[0]), int(ra[1])

        # Ankle fallback: try knees
        lk_ok = lk[2] > self.conf
        rk_ok = rk[2] > self.conf
        if lk_ok and rk_ok:
            return int((lk[0]+rk[0])/2), int((lk[1]+rk[1])/2)
        elif lk_ok:
            return int(lk[0]), int(lk[1])
        elif rk_ok:
            return int(rk[0]), int(rk[1])

        return None

    def callback(self, rgb_msg, points_msg):
        frame = self.br.imgmsg_to_cv2(rgb_msg, 'bgr8')
        results = self.model(frame, verbose=False)

        # Pick the person with the best ankle/knee detection
        best_pixel = None
        best_score = -1.0

        for result in results:
            if result.keypoints is None:
                continue
            for person_kps in result.keypoints.data:
                kps   = person_kps.cpu().numpy()   # (17, 3)
                pixel = self.get_ankle_midpoint(kps)
                if pixel is None:
                    continue
                score = sum(kps[i][2] for i in [13,14,15,16] if kps[i][2] > self.conf)
                if score > best_score:
                    best_score = score
                    best_pixel = pixel

        if best_pixel is None:
            return   # nobody visible — tracking_node will search

        cx, cy = best_pixel

        # Get 3D position from PointCloud2 (same as color_obj_detection.py)
        pointid = cy * points_msg.row_step + cx * points_msg.point_step
        try:
            X, Y, Z = struct.unpack_from('fff', points_msg.data, offset=pointid)
        except struct.error:
            return

        center_points = np.array([X, Y, Z])
        if np.any(np.isnan(center_points)) or np.all(center_points == 0.0):
            return

        # Transform camera frame → base_footprint
        try:
            tf = self.tf_buffer.lookup_transform(
                'base_footprint', rgb_msg.header.frame_id,
                rclpy.time.Time(), rclpy.duration.Duration(seconds=0.2))
            R = q2R([tf.transform.rotation.w, tf.transform.rotation.x,
                     tf.transform.rotation.y, tf.transform.rotation.z])
            t = np.array([tf.transform.translation.x,
                          tf.transform.translation.y,
                          tf.transform.translation.z])
            cp_robot = R @ center_points + t
        except TransformException as e:
            self.get_logger().error(f'TF error: {e}')
            return

        # Publish pose
        pose = PoseStamped()
        pose.header.frame_id = 'base_footprint'
        pose.header.stamp    = rgb_msg.header.stamp
        pose.pose.position.x = float(cp_robot[0])
        pose.pose.position.y = float(cp_robot[1])
        pose.pose.position.z = float(cp_robot[2])
        self.pub_pose.publish(pose)

        # Debug image
        vis = frame.copy()
        cv2.circle(vis, (cx, cy), 10, (0, 0, 255), -1)
        cv2.putText(vis, 'TARGET', (cx+12, cy),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,0,255), 2)
        self.pub_image.publish(self.br.cv2_to_imgmsg(vis, 'bgr8'))


def main(args=None):
    rclpy.init(args=args)
    rclpy.spin(PersonDetectionNode())
    rclpy.shutdown()

if __name__ == '__main__':
    main()
