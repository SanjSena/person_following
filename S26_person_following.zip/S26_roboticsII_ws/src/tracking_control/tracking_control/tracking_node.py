import rclpy, math
from rclpy.node import Node
from geometry_msgs.msg import Twist, PoseStamped
from tf2_ros import TransformException, Buffer, TransformListener
import numpy as np

def hat(k):
    khat=np.zeros((3,3))
    khat[0,1]=-k[2]; khat[0,2]=k[1]
    khat[1,0]=k[2];  khat[1,2]=-k[0]
    khat[2,0]=-k[1]; khat[2,1]=k[0]
    return khat

def q2R(q):
    I=np.identity(3); qhat=hat(q[1:4]); qhat2=qhat.dot(qhat)
    return I + 2*q[0]*qhat + 2*qhat2


class TrackingNode(Node):
    def __init__(self):
        super().__init__('tracking_node')

        self.obs_pose  = None
        self.goal_pose = None

        self.declare_parameter('world_frame_id',    'odom')
        self.declare_parameter('desired_distance',   1.0)   # m  — how far to stay behind person
        self.declare_parameter('dist_tolerance',     0.15)  # m  — don't move if within this band
        self.declare_parameter('kp_angular',         0.8)   # turn gain
        self.declare_parameter('kp_linear',          0.4)   # forward/back gain
        self.declare_parameter('heading_threshold',  0.5)   # rad — only drive fwd when facing person
        self.declare_parameter('detection_timeout',  2.0)   # s   — rotate to search after this
        self.declare_parameter('search_angular',     0.4)   # rad/s

        self._search_dir   = 1      # +1 = CCW, -1 = CW
        self._last_seen_t  = None

        self.tf_buffer   = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        # Publishes to /track_cmd_vel — joy_safety_ctrl gates it to /cmd_vel
        self.pub = self.create_publisher(Twist, '/track_cmd_vel', 10)

        self.create_subscription(PoseStamped, 'detected_color_object_pose',
                                 self._obs_cb, 10)
        self.create_subscription(PoseStamped, 'detected_color_goal_pose',
                                 self._goal_cb, 10)

        self.create_timer(0.01, self._loop)   # 100 Hz

    # ── helpers ───────────────────────────────────────────────────────────────

    def _to_odom(self, msg):
        odom = self.get_parameter('world_frame_id').get_parameter_value().string_value
        cp   = np.array([msg.pose.position.x, msg.pose.position.y, msg.pose.position.z])
        try:
            tf = self.tf_buffer.lookup_transform(
                odom, msg.header.frame_id,
                rclpy.time.Time(), rclpy.duration.Duration(seconds=0.1))
            R = q2R([tf.transform.rotation.w, tf.transform.rotation.x,
                     tf.transform.rotation.y, tf.transform.rotation.z])
            t = np.array([tf.transform.translation.x,
                          tf.transform.translation.y,
                          tf.transform.translation.z])
            return R @ cp + t
        except TransformException as e:
            self.get_logger().error(f'TF: {e}')
            return None

    def _obs_cb(self, msg):
        p = self._to_odom(msg)
        if p is not None: self.obs_pose = p

    def _goal_cb(self, msg):
        p = self._to_odom(msg)
        if p is not None:
            self.goal_pose   = p
            self._last_seen_t = self.get_clock().now()

    def _goal_in_base(self):
        """Return goal position in base_footprint frame."""
        odom = self.get_parameter('world_frame_id').get_parameter_value().string_value
        try:
            tf = self.tf_buffer.lookup_transform('base_footprint', odom, rclpy.time.Time())
            R  = q2R([tf.transform.rotation.w, tf.transform.rotation.x,
                      tf.transform.rotation.y, tf.transform.rotation.z])
            t  = np.array([tf.transform.translation.x,
                           tf.transform.translation.y,
                           tf.transform.translation.z])
            return R @ self.goal_pose + t
        except TransformException as e:
            self.get_logger().error(f'TF: {e}')
            return None

    # ── control loop ──────────────────────────────────────────────────────────

    def _loop(self):
        cmd = Twist()

        if self.goal_pose is None:
            self.pub.publish(cmd)
            return

        timeout = self.get_parameter('detection_timeout').get_parameter_value().double_value
        elapsed = (self.get_clock().now() - self._last_seen_t).nanoseconds / 1e9

        if elapsed > timeout:
            # Person lost — rotate toward last-known side to search
            spd = self.get_parameter('search_angular').get_parameter_value().double_value
            cmd.angular.z = spd * float(self._search_dir)
            self.pub.publish(cmd)
            return

        goal = self._goal_in_base()
        if goal is None:
            self.pub.publish(cmd)
            return

        gx, gy = goal[0], goal[1]

        distance = math.sqrt(gx**2 + gy**2)
        heading  = math.atan2(gy, gx)   # +ve = person is to the left

        # Remember which side person was on for search
        if   gy >  0.05: self._search_dir =  1
        elif gy < -0.05: self._search_dir = -1

        kp_ang  = self.get_parameter('kp_angular').get_parameter_value().double_value
        kp_lin  = self.get_parameter('kp_linear').get_parameter_value().double_value
        des_d   = self.get_parameter('desired_distance').get_parameter_value().double_value
        tol     = self.get_parameter('dist_tolerance').get_parameter_value().double_value
        h_thresh= self.get_parameter('heading_threshold').get_parameter_value().double_value

        # Turn to face person
        cmd.angular.z = float(np.clip(kp_ang * heading, -0.75, 0.75))

        # Drive forward/back only when roughly facing person
        dist_err = distance - des_d
        if abs(heading) < h_thresh and abs(dist_err) > tol:
            cmd.linear.x = float(np.clip(kp_lin * dist_err, -0.15, 0.15))

        self.pub.publish(cmd)


def main(args=None):
    rclpy.init(args=args)
    rclpy.spin(TrackingNode())
    rclpy.shutdown()

if __name__ == '__main__':
    main()
