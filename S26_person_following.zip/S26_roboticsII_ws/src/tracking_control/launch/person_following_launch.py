from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([

        Node(
            package='object_detection',
            executable='person_detection_node',
            name='person_detection_node',
            output='screen',
        ),

        Node(
            package='tracking_control',
            executable='tracking_node',
            name='tracking_node',
            output='screen',
            parameters=[{
                'desired_distance':  1.0,   # metres behind person
                'dist_tolerance':    0.15,
                'kp_angular':        0.8,
                'kp_linear':         0.4,
                'heading_threshold': 0.5,
                'detection_timeout': 2.0,
                'search_angular':    0.4,
            }]
        ),

    ])
